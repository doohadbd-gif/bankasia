export interface Story {
  id: number;
  title: string;
  personName: string;
  thumbnail: string;
  audioFile: string;
  duration: string;
}

export interface DivisionData {
  id: string;
  name: string;
  position: { x: number; y: number };
  position3D: { x: number; y: number; z: number };
  mainStory: {
    personName: string;
    personTitle: string;
    personImage: string;
    audioFile: string;
    audioDuration: string;
    quote: string;
  };
  moreStories: Story[];
}

export const divisionsData: DivisionData[] = [
  {
    id: 'dhaka',
    name: 'Dhaka',
    position: { x: 52, y: 48 },
    position3D: { x: 0.15, y: 0.05, z: 0.1 },
    mainStory: {
      personName: 'Abdul Karim',
      personTitle: 'Small Business Owner, Dhaka',
      personImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '2:45',
      quote: 'Bank Asia helped me transform my small shop into a thriving business.'
    },
    moreStories: [
      {
        id: 101,
        title: 'From Street Vendor to Shop Owner',
        personName: 'Rahim Khan',
        thumbnail: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:15'
      },
      {
        id: 102,
        title: 'A Mother\'s Dream Fulfilled',
        personName: 'Fatima Begum',
        thumbnail: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '3:02'
      }
    ]
  },
  {
    id: 'chittagong',
    name: 'Chittagong',
    position: { x: 72, y: 62 },
    position3D: { x: 0.35, y: -0.1, z: 0.12 },
    mainStory: {
      personName: 'Jamal Uddin',
      personTitle: 'Fisherman, Chittagong',
      personImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '3:12',
      quote: 'The loan helped me buy a new boat and support my family better.'
    },
    moreStories: [
      {
        id: 201,
        title: 'Waves of Change',
        personName: 'Kamal Hossain',
        thumbnail: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:45'
      }
    ]
  },
  {
    id: 'rajshahi',
    name: 'Rajshahi',
    position: { x: 22, y: 35 },
    position3D: { x: -0.25, y: 0.2, z: 0.08 },
    mainStory: {
      personName: 'Nasreen Akhter',
      personTitle: 'Mango Farmer, Rajshahi',
      personImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '2:58',
      quote: 'My mango orchard doubled in size thanks to Bank Asia\'s agricultural loan.'
    },
    moreStories: [
      {
        id: 301,
        title: 'Sweet Success',
        personName: 'Rafiq Ahmed',
        thumbnail: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:30'
      }
    ]
  },
  {
    id: 'khulna',
    name: 'Khulna',
    position: { x: 30, y: 68 },
    position3D: { x: -0.2, y: -0.15, z: 0.09 },
    mainStory: {
      personName: 'Shafiq Rahman',
      personTitle: 'Shrimp Farmer, Khulna',
      personImage: 'https://images.unsplash.com/photo-1480429370612-e9c8e44d5e75?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '3:25',
      quote: 'Bank Asia understood my business needs when others didn\'t.'
    },
    moreStories: [
      {
        id: 401,
        title: 'From Ponds to Prosperity',
        personName: 'Mamun Ali',
        thumbnail: 'https://images.unsplash.com/photo-1463453091185-61582044d556?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:50'
      }
    ]
  },
  {
    id: 'sylhet',
    name: 'Sylhet',
    position: { x: 78, y: 22 },
    position3D: { x: 0.4, y: 0.35, z: 0.15 },
    mainStory: {
      personName: 'Habib Chowdhury',
      personTitle: 'Tea Garden Owner, Sylhet',
      personImage: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '2:40',
      quote: 'Three generations of tea farming, now expanding with Bank Asia\'s support.'
    },
    moreStories: [
      {
        id: 501,
        title: 'Leaves of Hope',
        personName: 'Sumon Das',
        thumbnail: 'https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '3:10'
      }
    ]
  },
  {
    id: 'barisal',
    name: 'Barisal',
    position: { x: 48, y: 75 },
    position3D: { x: 0.05, y: -0.3, z: 0.07 },
    mainStory: {
      personName: 'Salma Khatun',
      personTitle: 'Rice Farmer, Barisal',
      personImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '2:55',
      quote: 'The riverine lands of Barisal now yield more thanks to better equipment.'
    },
    moreStories: [
      {
        id: 601,
        title: 'Rivers of Opportunity',
        personName: 'Faruk Mia',
        thumbnail: 'https://images.unsplash.com/photo-1499996860823-5f6fef299078?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:20'
      }
    ]
  },
  {
    id: 'rangpur',
    name: 'Rangpur',
    position: { x: 32, y: 12 },
    position3D: { x: -0.1, y: 0.45, z: 0.11 },
    mainStory: {
      personName: 'Aminul Islam',
      personTitle: 'Potato Farmer, Rangpur',
      personImage: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '3:05',
      quote: 'Cold storage facility funded by Bank Asia changed everything for us.'
    },
    moreStories: [
      {
        id: 701,
        title: 'Seeds of Progress',
        personName: 'Rashid Khan',
        thumbnail: 'https://images.unsplash.com/photo-1504257432389-52343af06ae3?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:35'
      }
    ]
  },
  {
    id: 'mymensingh',
    name: 'Mymensingh',
    position: { x: 58, y: 28 },
    position3D: { x: 0.2, y: 0.25, z: 0.13 },
    mainStory: {
      personName: 'Roksana Parvin',
      personTitle: 'Dairy Farmer, Mymensingh',
      personImage: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=400&fit=crop&crop=face',
      audioFile: '/audio/demo-story.mp3',
      audioDuration: '2:48',
      quote: 'My dairy farm now supplies milk to the entire district.'
    },
    moreStories: [
      {
        id: 801,
        title: 'Milk of Success',
        personName: 'Babul Haque',
        thumbnail: 'https://images.unsplash.com/photo-1528892952291-009c663ce843?w=100&h=100&fit=crop&crop=face',
        audioFile: '/audio/demo-story.mp3',
        duration: '2:40'
      }
    ]
  }
];
