import { useState, useCallback } from 'react';
import { divisionsData, DivisionData } from '@/data/storyData';
import { cn } from '@/lib/utils';

interface BangladeshMapProps {
  onSelectDivision: (division: DivisionData) => void;
}

export const BangladeshMap = ({ onSelectDivision }: BangladeshMapProps) => {
  const [hoveredDivision, setHoveredDivision] = useState<string | null>(null);

  const handleDivisionClick = useCallback((division: DivisionData) => {
    onSelectDivision(division);
  }, [onSelectDivision]);

  return (
    <div className="relative w-full h-full">
      {/* SVG Map of Bangladesh */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        style={{ filter: 'drop-shadow(0 20px 40px rgba(0, 0, 0, 0.25))' }}
      >
        <defs>
          {/* Gradient for map fill */}
          <linearGradient id="mapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="50%" stopColor="#f8fafc" />
            <stop offset="100%" stopColor="#f1f5f9" />
          </linearGradient>
          
          {/* Glow filter */}
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          
          {/* Drop shadow for map */}
          <filter id="mapShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor="rgba(0,0,0,0.15)"/>
          </filter>
        </defs>
        
        {/* Bangladesh Map Shape - More accurate outline */}
        <path
          d="M 50 2 
             Q 58 4, 68 8
             L 75 12 Q 82 16, 88 22
             Q 92 28, 90 38
             Q 88 48, 85 58
             L 80 68 Q 75 78, 65 85
             Q 55 92, 45 90
             L 35 86 Q 25 82, 20 72
             Q 15 62, 18 50
             L 15 40 Q 12 28, 18 18
             Q 25 8, 38 4
             Q 44 2, 50 2
             Z"
          fill="url(#mapGradient)"
          stroke="#4f9ef8"
          strokeWidth="1"
          filter="url(#mapShadow)"
          className="transition-all duration-300"
        />
        
        {/* Internal Rivers/Detail lines */}
        <g stroke="#94c4f8" strokeWidth="0.5" fill="none" opacity="0.5">
          <path d="M 40 25 Q 50 30, 55 25" strokeDasharray="3,2" />
          <path d="M 30 45 Q 45 50, 60 45" strokeDasharray="3,2" />
          <path d="M 35 65 Q 50 70, 58 65" strokeDasharray="3,2" />
          <path d="M 55 35 Q 60 45, 58 55" strokeDasharray="2,2" />
          <path d="M 35 35 Q 40 45, 38 55" strokeDasharray="2,2" />
        </g>
      </svg>

      {/* Division Landmarks */}
      {divisionsData.map((division) => (
        <button
          key={division.id}
          onClick={() => handleDivisionClick(division)}
          onMouseEnter={() => setHoveredDivision(division.id)}
          onMouseLeave={() => setHoveredDivision(null)}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer touch-manipulation"
          style={{
            left: `${division.position.x}%`,
            top: `${division.position.y}%`,
          }}
          aria-label={`Listen to story from ${division.name}`}
        >
          {/* Glow ring on hover */}
          <div className={cn(
            "absolute inset-0 rounded-full transition-all duration-300",
            hoveredDivision === division.id 
              ? "scale-[2.5] opacity-100 bg-accent/30 blur-md" 
              : "scale-100 opacity-0"
          )} />
          
          {/* Pulse ring */}
          <div className={cn(
            "absolute inset-0 rounded-full border-2 border-primary/50 animate-pulse-glow",
            hoveredDivision === division.id ? "scale-150" : "scale-100"
          )} />
          
          {/* Pin marker */}
          <div className={cn(
            "relative w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg",
            "bg-gradient-to-br from-primary to-primary/80",
            hoveredDivision === division.id 
              ? "scale-125 shadow-2xl shadow-primary/50" 
              : "scale-100 animate-float",
            // Stagger animation
            division.id === 'dhaka' && "[animation-delay:0ms]",
            division.id === 'chittagong' && "[animation-delay:200ms]",
            division.id === 'rajshahi' && "[animation-delay:400ms]",
            division.id === 'khulna' && "[animation-delay:600ms]",
            division.id === 'sylhet' && "[animation-delay:800ms]",
            division.id === 'barisal' && "[animation-delay:1000ms]",
            division.id === 'rangpur' && "[animation-delay:1200ms]",
            division.id === 'mymensingh' && "[animation-delay:1400ms]",
          )}>
            {/* Play icon */}
            <svg 
              viewBox="0 0 24 24" 
              fill="currentColor" 
              className="w-4 h-4 md:w-5 md:h-5 text-primary-foreground ml-0.5"
            >
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
          
          {/* Label */}
          <div className={cn(
            "absolute top-full left-1/2 -translate-x-1/2 mt-2 whitespace-nowrap transition-all duration-300",
            "px-3 py-1.5 rounded-lg text-xs md:text-sm font-semibold",
            "bg-card text-card-foreground shadow-lg",
            hoveredDivision === division.id 
              ? "opacity-100 translate-y-0" 
              : "opacity-0 -translate-y-2 pointer-events-none"
          )}>
            {division.name}
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-card rotate-45" />
          </div>
        </button>
      ))}
    </div>
  );
};

export default BangladeshMap;
