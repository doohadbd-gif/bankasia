export const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-primary flex items-center justify-center z-50">
      <div className="text-center">
        {/* Animated loader */}
        <div className="relative w-20 h-20 mb-6 mx-auto">
          <div className="absolute inset-0 border-4 border-primary-foreground/30 rounded-full" />
          <div className="absolute inset-0 border-4 border-t-primary-foreground rounded-full animate-spin" />
        </div>
        
        <h2 className="text-xl font-semibold text-primary-foreground mb-2">
          Loading Stories...
        </h2>
        <p className="text-sm text-primary-foreground/70">
          Discover tales from across Bangladesh
        </p>
      </div>
    </div>
  );
};

export default LoadingScreen;
