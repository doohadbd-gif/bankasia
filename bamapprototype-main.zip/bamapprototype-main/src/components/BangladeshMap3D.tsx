import { useState, useCallback, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import { divisionsData, DivisionData } from '@/data/storyData';
import * as THREE from 'three';

interface BangladeshMap3DProps {
  onSelectDivision: (division: DivisionData) => void;
}

// 3D Landmark Pin Component
const LandmarkPin = ({ 
  division, 
  onClick, 
  isHovered,
  onHover,
  onUnhover
}: { 
  division: DivisionData;
  onClick: () => void;
  isHovered: boolean;
  onHover: () => void;
  onUnhover: () => void;
}) => {
  const meshRef = useRef<THREE.Group>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      const baseY = division.position3D.y;
      meshRef.current.position.y = baseY + Math.sin(state.clock.elapsedTime * 2 + division.position3D.x * 10) * 0.02;
      const targetScale = isHovered ? 1.4 : 1;
      meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    }
    if (glowRef.current) {
      const intensity = 0.3 + Math.sin(state.clock.elapsedTime * 3) * 0.15;
      (glowRef.current.material as THREE.MeshBasicMaterial).opacity = isHovered ? intensity * 2 : intensity;
    }
  });

  return (
    <group
      ref={meshRef}
      position={[division.position3D.x, division.position3D.y, division.position3D.z]}
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      onPointerOver={(e) => { e.stopPropagation(); onHover(); document.body.style.cursor = 'pointer'; }}
      onPointerOut={() => { onUnhover(); document.body.style.cursor = 'default'; }}
    >
      <mesh ref={glowRef} position={[0, 0.08, 0]}>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshBasicMaterial color="#4f9ef8" transparent opacity={0.3} blending={THREE.AdditiveBlending} />
      </mesh>
      <mesh><cylinderGeometry args={[0.03, 0.03, 0.12, 16]} /><meshStandardMaterial color="#005BAA" metalness={0.6} roughness={0.3} /></mesh>
      <mesh position={[0, 0.08, 0]}>
        <sphereGeometry args={[0.055, 16, 16]} />
        <meshStandardMaterial color={isHovered ? "#00A6FF" : "#FFFFFF"} metalness={0.4} roughness={0.2} emissive={isHovered ? "#00A6FF" : "#000000"} emissiveIntensity={isHovered ? 0.5 : 0} />
      </mesh>
      <mesh position={[0, 0.08, 0.04]} rotation={[0, 0, -Math.PI / 2]}><coneGeometry args={[0.02, 0.03, 3]} /><meshStandardMaterial color="#005BAA" /></mesh>
      {isHovered && (
        <Html position={[0, 0.2, 0]} center distanceFactor={2} style={{ pointerEvents: 'none' }}>
          <div className="px-3 py-1.5 bg-card text-card-foreground rounded-lg shadow-lg text-sm font-semibold whitespace-nowrap">{division.name}</div>
        </Html>
      )}
    </group>
  );
};

// Simple map shape
const MapShape = () => (
  <mesh position={[0, 0, -0.1]} rotation={[0, 0, 0]}>
    <planeGeometry args={[1.8, 2.2]} />
    <meshStandardMaterial color="#e8f4fc" transparent opacity={0.85} side={THREE.DoubleSide} />
  </mesh>
);

export const BangladeshMap3D = ({ onSelectDivision }: BangladeshMap3DProps) => {
  const [hoveredDivision, setHoveredDivision] = useState<string | null>(null);
  const handleDivisionClick = useCallback((division: DivisionData) => { onSelectDivision(division); }, [onSelectDivision]);

  return (
    <div className="relative w-full h-full">
      <Canvas camera={{ position: [0, 0, 3], fov: 50 }} dpr={[1, 2]} gl={{ antialias: true, alpha: true }} style={{ background: 'transparent' }}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[5, 10, 5]} intensity={1} />
        <pointLight position={[0, 5, 0]} intensity={0.5} color="#4f9ef8" />
        <MapShape />
        {divisionsData.map((division) => (
          <LandmarkPin key={division.id} division={division} onClick={() => handleDivisionClick(division)} isHovered={hoveredDivision === division.id} onHover={() => setHoveredDivision(division.id)} onUnhover={() => setHoveredDivision(null)} />
        ))}
        <OrbitControls enablePan={false} enableRotate={false} enableZoom={true} minDistance={2} maxDistance={6} zoomSpeed={0.5} />
      </Canvas>
    </div>
  );
};

export default BangladeshMap3D;
