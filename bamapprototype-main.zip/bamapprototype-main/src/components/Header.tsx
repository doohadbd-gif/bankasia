import bankAsiaLogo from '@/assets/bank-asia-logo.webp';

export const Header = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 p-4 md:p-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <a 
          href="https://www.bankasia-bd.com" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center gap-2 group bg-card/90 backdrop-blur-sm px-4 py-2 rounded-xl shadow-lg"
        >
          <img 
            src={bankAsiaLogo} 
            alt="Bank Asia" 
            className="h-8 md:h-10 object-contain transition-transform group-hover:scale-105"
          />
        </a>
        
        {/* Title */}
        <div className="text-right bg-card/90 backdrop-blur-sm px-4 py-2 rounded-xl shadow-lg">
          <h1 className="text-lg md:text-xl font-bold text-card-foreground">
            The Tale of the People
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground">
            Stories from across Bangladesh
          </p>
        </div>
      </div>
    </header>
  );
};

export default Header;
