import { X, BookOpen, ExternalLink, Quote } from 'lucide-react';
import { DivisionData } from '@/data/storyData';
import AudioPlayer from './AudioPlayer';
import { cn } from '@/lib/utils';

interface PrimaryPopupProps {
  division: DivisionData;
  onClose: () => void;
  onMoreStories: () => void;
}

export const PrimaryPopup = ({ division, onClose, onMoreStories }: PrimaryPopupProps) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Popup Card */}
      <div className="relative bg-card text-card-foreground rounded-2xl shadow-2xl w-[480px] max-w-[95vw] max-h-[90vh] overflow-hidden animate-scale-in">
        
        {/* Animated Background Gradient */}
        <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
          <div 
            className="absolute inset-0 opacity-30 animate-gradient-shift"
            style={{
              background: 'linear-gradient(135deg, hsl(var(--primary) / 0.15) 0%, hsl(var(--accent) / 0.1) 50%, hsl(var(--primary) / 0.15) 100%)',
              backgroundSize: '200% 200%'
            }}
          />
        </div>
        
        {/* Content */}
        <div className="relative z-10 p-6 md:p-8 overflow-y-auto max-h-[90vh]">
          {/* Close button */}
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 bg-muted hover:bg-muted/80 rounded-full shadow-lg flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
          
          {/* Header - Division name */}
          <div className="text-center mb-6">
            <span className="inline-block px-4 py-1.5 bg-primary/10 text-primary text-sm font-medium rounded-full mb-3">
              {division.name} Division
            </span>
            <h2 className="text-2xl md:text-3xl font-bold text-card-foreground">
              The Tale of the People
            </h2>
          </div>
          
          {/* Person Image */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full animate-pulse-glow" />
              <img 
                src={division.mainStory.personImage}
                alt={division.mainStory.personName}
                className="relative w-32 h-32 md:w-40 md:h-40 rounded-full object-cover ring-4 ring-primary shadow-xl"
                loading="lazy"
              />
            </div>
          </div>
          
          {/* Person Details */}
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-card-foreground">
              {division.mainStory.personName}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {division.mainStory.personTitle}
            </p>
          </div>
          
          {/* Quote */}
          <div className="relative bg-muted/30 rounded-xl p-4 mb-6">
            <Quote className="absolute top-2 left-2 w-6 h-6 text-primary/30" />
            <p className="text-sm md:text-base text-muted-foreground italic pl-6">
              "{division.mainStory.quote}"
            </p>
          </div>
          
          {/* Audio Player */}
          <AudioPlayer audioUrl={division.mainStory.audioFile} />
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 mt-6">
            <button 
              onClick={onMoreStories}
              className={cn(
                "flex-1 px-5 py-3 border-2 border-primary text-primary rounded-xl font-semibold",
                "hover:bg-primary/10 transition-colors flex items-center justify-center gap-2"
              )}
            >
              <BookOpen className="w-5 h-5" />
              More Stories
            </button>
            
            <a 
              href="https://www.bankasia-bd.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className={cn(
                "flex-1 px-5 py-3 bg-primary text-primary-foreground rounded-xl font-semibold",
                "hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              )}
            >
              <ExternalLink className="w-5 h-5" />
              Visit Bank Asia
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrimaryPopup;
