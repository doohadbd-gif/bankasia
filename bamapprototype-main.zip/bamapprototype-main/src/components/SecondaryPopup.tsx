import { X } from 'lucide-react';
import { DivisionData, Story } from '@/data/storyData';
import AudioPlayer from './AudioPlayer';

interface SecondaryPopupProps {
  division: DivisionData;
  onClose: () => void;
}

export const SecondaryPopup = ({ division, onClose }: SecondaryPopupProps) => {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Darker backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-md"
        onClick={onClose}
      />
      
      <div className="relative bg-card text-card-foreground rounded-2xl shadow-2xl w-[550px] max-w-[95vw] max-h-[80vh] overflow-hidden animate-slide-in-bottom">
        
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border p-5 flex justify-between items-center z-10">
          <div>
            <h2 className="text-xl font-bold text-card-foreground">
              More Stories
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {division.name} Division
            </p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-muted hover:bg-muted/80 rounded-full flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
        
        {/* Scrollable Story List */}
        <div className="overflow-y-auto max-h-[calc(80vh-80px)] overscroll-contain">
          {division.moreStories.length > 0 ? (
            division.moreStories.map((story: Story) => (
              <div 
                key={story.id}
                className="p-4 border-b border-border/50 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-start gap-4">
                  {/* Thumbnail */}
                  <img 
                    src={story.thumbnail}
                    alt={story.personName}
                    className="w-14 h-14 rounded-xl object-cover flex-shrink-0 shadow-md"
                    loading="lazy"
                  />
                  
                  {/* Story Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-card-foreground text-base leading-tight">
                      {story.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {story.personName}
                    </p>
                    
                    {/* Mini Audio Player */}
                    <div className="mt-3">
                      <AudioPlayer 
                        audioUrl={story.audioFile} 
                        compact 
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              <p>More stories coming soon from {division.name}!</p>
            </div>
          )}
          
          {/* Call to action */}
          <div className="p-5 bg-muted/30">
            <p className="text-center text-sm text-muted-foreground mb-3">
              Want to share your story with Bank Asia?
            </p>
            <a 
              href="https://www.bankasia-bd.com/contact" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block w-full py-3 bg-primary text-primary-foreground rounded-xl font-semibold text-center hover:opacity-90 transition-opacity"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecondaryPopup;
