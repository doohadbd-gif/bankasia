import { useState, useEffect, useCallback } from 'react';
import background from '@/assets/background.png';
import Header from '@/components/Header';
import BangladeshMap3D from '@/components/BangladeshMap3D';
import PrimaryPopup from '@/components/PrimaryPopup';
import SecondaryPopup from '@/components/SecondaryPopup';
import LoadingScreen from '@/components/LoadingScreen';
import { DivisionData } from '@/data/storyData';

const Index = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDivision, setSelectedDivision] = useState<DivisionData | null>(null);
  const [showMoreStories, setShowMoreStories] = useState(false);

  useEffect(() => {
    // Quick load
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, []);

  const handleSelectDivision = useCallback((division: DivisionData) => {
    setSelectedDivision(division);
    setShowMoreStories(false);
  }, []);

  const handleClosePrimary = useCallback(() => {
    setSelectedDivision(null);
    setShowMoreStories(false);
  }, []);

  const handleOpenMoreStories = useCallback(() => {
    setShowMoreStories(true);
  }, []);

  const handleCloseMoreStories = useCallback(() => {
    setShowMoreStories(false);
  }, []);

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showMoreStories) {
          setShowMoreStories(false);
        } else if (selectedDivision) {
          setSelectedDivision(null);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showMoreStories, selectedDivision]);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className="fixed inset-0 -z-10"
        style={{
          backgroundImage: `url(${background})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }}
      >
        {/* Overlay gradient for better contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/20 via-transparent to-primary/30" />
      </div>

      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="relative min-h-screen flex items-center justify-center pt-20 pb-8 px-4">
        <div className="w-full max-w-4xl aspect-[4/5] md:aspect-[3/4] lg:aspect-square relative animate-fade-in">
          {/* Map Container */}
          <div className="w-full h-full">
            <BangladeshMap3D onSelectDivision={handleSelectDivision} />
          </div>
          
          {/* Instructions */}
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-center">
            <p className="text-sm text-foreground/80 bg-card/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
              👆 Tap a location to hear their story
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 right-0 p-4 text-center">
        <p className="text-xs text-foreground/60">
          © {new Date().getFullYear()} Bank Asia Ltd. All rights reserved.
        </p>
      </footer>

      {/* Popups */}
      {selectedDivision && (
        <PrimaryPopup
          division={selectedDivision}
          onClose={handleClosePrimary}
          onMoreStories={handleOpenMoreStories}
        />
      )}

      {selectedDivision && showMoreStories && (
        <SecondaryPopup
          division={selectedDivision}
          onClose={handleCloseMoreStories}
        />
      )}
    </div>
  );
};

export default Index;
